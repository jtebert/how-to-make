import pygame
import pygame.locals as pg_locals
import sys
import params
import random
import serial


class Birdy(pygame.sprite.Sprite):

    def __init__(self):
        """
        Create a bird that starts in the middle left of the screen
        """
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load("birdy.png")
        self.rect = self.image.get_rect()

        self.rect.x = self.rect.width/2
        self.rect.y = 0


class Obstacle(pygame.sprite.Sprite):
    def __init__(self, x, y, height):
        """
        Create a rectangular obstacle that moves across the screen (R->L)
        :param x: x position of obstacle center 
        :param y: y positino of obstacle center
        :param height: height of the obstacle rectangle
        """
        pygame.sprite.Sprite.__init__(self)

        self.color = pygame.color.Color(params.colors['obstacle'])
        self.image = pygame.Surface([params.obstacle_width, height])
        self.image.fill(self.color)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        """
        Shift to the left by velocity parameter and destroy any that went off screen to left
        :return: None
        """
        self.rect.x -= params.birdy_vel
        if self.rect.x < -2*params.obstacle_width:
            self.kill()


class Environment:

    def __init__(self, scene, ser):
        """
        Create a wrapper environment containing all elements of the world
        :param scene: 
        :param serial_port: 
        """
        self.height = params.screen_height
        self.width = params.screen_width
        self.obstacles = pygame.sprite.Group()
        self.birdy = Birdy()
        self.all_sprites = pygame.sprite.Group(self.birdy)
        self.scene = scene
        self.filt_val = 0.0
        self.ser = ser
        self.score = 0

    def read_val(self):
        """
        Read values from the serial port until a new valid value is found
        :return: None (Changes self.filt_val to filtered 10-bit reading)
        """
        byte2 = 0
        byte3 = 0
        byte4 = 0
        self.ser.flush()
        while 1:
            # Find framing
            byte1 = byte2
            byte2 = byte3
            byte3 = byte4
            byte4 = ord(self.ser.read())
            if (byte1 == 1) and (byte2 == 2) and (byte3 == 3) and (byte4 == 4):
                break
        low = ord(self.ser.read())
        high = ord(self.ser.read())
        value = 256 * high + low
        self.filt_val = (1 - params.eps) * self.filt_val + params.eps * value

    def create_new_obstacle(self):
        """
        Create new obstacle to enter on the right
        :return: None (adds new obstacles to self.obstacles and self.all_sprites)
        """
        if len(self.obstacles) == 0:
            # Add obstacle if there are none (start of game)
            do_add_obstacle = True
        else:
            # Add obstacle if there's the correct gap from the previous one
            do_add_obstacle = max([ob.rect.x for ob in self.obstacles]) <= \
                           self.width - (params.obstacle_width+params.obstacle_gap)
        if do_add_obstacle:
            x = self.width
            # Obstacle above gap
            height1 = random.randrange(0, self.height-params.obstacle_opening)
            ob1 = Obstacle(x, 0, height1)
            self.obstacles.add(ob1)
            self.all_sprites.add(ob1)
            # Obstacle below gap
            height2 = self.height - height1 - params.obstacle_opening
            ob2 = Obstacle(x, self.height-height2, height2)
            self.obstacles.add(ob2)
            self.all_sprites.add(ob2)

    def update(self):
        """
        Move and create obstacles, position birdy according to reading, increment score
        :return: None
        """
        self.all_sprites.update()
        self.create_new_obstacle()
        self.birdy.rect.y = self.filt_val/1024*(self.height-self.birdy.rect.height)
        self.score += 1

    def draw(self):
        """
        Draw all sprites (obstacles and birdy)
        :return: None
        """
        self.all_sprites.draw(self.scene)

    def is_game_over(self):
        """
        Check if birdy has hit any obstacles
        :return: Boolean (did birdy collide)
        """
        return pygame.sprite.spritecollide(self.birdy, self.obstacles, False)

    def restart_game(self):
        """
        Reset the game (remove obstacles, reset score and birdy)
        :return: None
        """
        self.score = 0
        self.obstacles = pygame.sprite.Group()
        self.birdy = Birdy()
        self.all_sprites = pygame.sprite.Group(self.birdy)


def main(port):
    """
    Run the Pygame stuff
    :param port: String name of serial port
    :return: None
    """

    # Initialize game and pygame setup
    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode((params.screen_width, params.screen_height))
    clock = pygame.time.Clock()
    running = True
    game_over = False

    # Extras for drawing (text, buttons)
    score_font = pygame.font.SysFont('Open Sans', 32)
    over_font = pygame.font.SysFont('Open Sans', 64)
    button = pygame.Rect(0, 0, params.screen_width/2, 200)
    button_color = pygame.color.Color(params.colors['game-over'])

    # Create environment and open serial port
    ser = serial.Serial(port, 9600)
    env = Environment(screen, ser)

    # Game loop
    while running:
        for event in pygame.event.get():
            # Quitting game
            if event.type == pg_locals.QUIT:
                running = False
            elif event.type == pg_locals.KEYDOWN and event.key == pg_locals.K_ESCAPE:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN and game_over:
                # Button interaction when in game over state
                mouse_pos = pygame.mouse.get_pos()
                if button.collidepoint(mouse_pos):
                    env.restart_game()
                    game_over = False

        # Change button color on mouseover
        if game_over:
            mouse_pos = pygame.mouse.get_pos()
            if button.collidepoint(mouse_pos):
                button_color = pygame.color.Color(params.colors['game-over-hover'])
            else:
                button_color = pygame.color.Color(params.colors['game-over'])

        # UPDATE
        if not game_over:
            env.update()
            env.read_val()
            game_over = env.is_game_over()

        # DRAW
        # Clear screen
        screen.fill(pygame.color.Color(params.colors['sky']))
        # Draw sprites
        env.draw()
        # Draw light level and score text
        textsurface = score_font.render('Light: ' + str(int(env.filt_val)), True, (0, 0, 0))
        screen.blit(textsurface, (150, 10))
        textsurface = score_font.render('Score: ' + str(env.score), True, (0, 0, 0))
        screen.blit(textsurface, (150, 40))
        if game_over:
            # Draw button
            button.center = (params.screen_width / 2, params.screen_height / 2)
            pygame.draw.rect(screen, button_color, button)
            # Draw game over & restart text
            textsurface = over_font.render('GAME OVER', True, (255, 255, 255))
            text_rect = textsurface.get_rect(center=(params.screen_width / 2, params.screen_height / 2-35))
            screen.blit(textsurface, text_rect)
            textsurface = score_font.render('Click here to restart', True, (255, 255, 255))
            text_rect = textsurface.get_rect(center=(params.screen_width / 2, params.screen_height / 2 + 40))
            screen.blit(textsurface, text_rect)

        # Flip screen and tick clock
        pygame.display.flip()
        clock.tick(60)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "Must provide serial port as argument (e.g. /dev/ttyUSB0)"
        sys.exit()
    serial_port = sys.argv[1]
    sys.exit(main(serial_port))

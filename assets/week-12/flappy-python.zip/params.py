# Screen parameters
screen_width = 800
screen_height = 500

# Game speed
birdy_vel = 6  # pixels/tick

# Obstacle parameters
obstacle_width = 60
obstacle_opening = 120
obstacle_gap = 180

# Filter for serial port readings
eps = 0.5  # filter time constant

# Colors for drawing
colors = {
    'sky': '#4fc3f7',
    'obstacle': '#4caf50',
    'game-over': '#03a9f4',
    'game-over-hover': '#0288d1'
}
